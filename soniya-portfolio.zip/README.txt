Soniya Dhull - Portfolio Website
================================

Files
-----
index.html   The complete website (HTML, CSS, JavaScript and images are all inside this one file).

How to open
-----------
Double-click index.html to open it in your browser (Chrome is best).

How to put it online (free)
---------------------------
1. Netlify:  go to app.netlify.com/drop and drag this folder (or the zip) onto the page.
2. Vercel / GitHub Pages also work: upload index.html as the home page.

Say Hello form
--------------
The first message sent from the form makes FormSubmit email you a confirmation.
Click "Activate" in that email once; after that all messages arrive in your Gmail.

How to edit
-----------
Open index.html in any text editor (Notepad, VS Code). Search for text you want to change
(for example "View Project" or the FAQ answers) and edit it.
